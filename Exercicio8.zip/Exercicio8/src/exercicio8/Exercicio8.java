package exercicio8;

/**
 * Exercicio 8 do teste da S2IT.
 *
 * @author Rodrigo de Lima Salvador
 */
public class Exercicio8 {

    public static final int maxValueC = 1000000;

    public static void main(String[] args) {

        int a = 135;
        int b = 246;
        // se int iniciar com zero é interpretado como octal
        int c = getC(a, b);
        System.out.println("c: " + c);
    }

    /**
     * Dados dois numeros inteiros A e B, a funcao gera um outro inteiro C.
     *
     * @param a Inteiro
     * @param b Inteiro
     * @return Concatena os valores de a e b e gera um outro inteiro c
     */
    private static int getC(int a, int b) {
        
        System.out.println("a: " + a);
        System.out.println("b: " + b);
        System.out.println();
        
        String strA = String.valueOf(a);
        String strB = String.valueOf(b);
        char[] arrA = strA.toCharArray();
        char[] arrB = strB.toCharArray();
        StringBuilder strResult = new StringBuilder();
        if (arrA.length >= arrB.length) {
            for (int i = 0; i < strA.length(); i++) {
                int resA = getCharInArray(i, arrA);
                int resB = getCharInArray(i, arrB);
                if (resA != -1) {
                    strResult.append(resA);
                }
                if (resB != -1) {
                    strResult.append(resB);
                }
            }
            int result = Integer.parseInt(strResult.toString());
            if (result > Exercicio8.maxValueC) {
                return -1;
            } else {
                return result;
            }
        } else {
            // for no arrB
            for (int i = 0; i < strB.length(); i++) {
                int resA = getCharInArray(i, arrA);
                int resB = getCharInArray(i, arrB);
                if (resA != -1) {
                    strResult.append(resA);
                }
                if (resB != -1) {
                    strResult.append(resB);
                }
            }
            int result = Integer.parseInt(strResult.toString());
            if (result > Exercicio8.maxValueC) {
                return -1;
            } else {
                return result;
            }
        } 
    }

    /**
     * Converte um char no array com indice x, somente se o indice esta dentro
     * do array.
     *
     * @param index indice do array
     * @param array array de caracter
     * @return o valor encontrado se existe no array ou -1 se nao existe o
     * indice no array
     */
    public static int getCharInArray(int index, char[] array) {
        try {
            return Integer.parseInt(String.valueOf(array[index]));
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException ex) {
            return -1;
        }
    }

}
