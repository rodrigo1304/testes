package exercicio9;

/**
 * Classe que representa a arvore binaria.
 *
 * @author Rodrigo de Lima Salvador
 */
public class BinaryTree {

    private Node root;
    
    public Node insertNode(int valor) {
        if (root == null) {
            root = new Node(valor);
            return root;
        } else {
            Node newNode = new Node(valor);
            return inserirNode(root, newNode);
        }
    }
    
    private Node inserirNode(Node btree, Node newNode) {
        if (newNode.getValor() > btree.getValor()) {
            if (btree.getRight() == null) {
                btree.setRight(newNode);
                return newNode;
            } else {
                return inserirNode(btree.getRight(), newNode);
            }
        } else {
            if (btree.getLeft() == null) {
                btree.setLeft(newNode);
                return newNode;
            } else {
                return inserirNode(btree.getLeft(), newNode);
            }
        }
    }
    
    public int sum(Node node) {
        return node.sum();
    }
    
    
}
