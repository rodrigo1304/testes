package exercicio9;

/**
 * Exercicio 9 do teste da S2IT.
 *
 * @author Rodrigo de Lima Salvador
 */
public class Exercicio9 {

    public static void main(String[] args) {
        BinaryTree btree = new BinaryTree();
        Node root = btree.insertNode(10);
        Node node1 = btree.insertNode(15);
        Node node2 = btree.insertNode(12);
        Node node3 = btree.insertNode(11);
        Node node4 = btree.insertNode(9);
        Node node5 = btree.insertNode(7);
        Node node6 = btree.insertNode(2);
        System.out.println("Soma: " + btree.sum(node3));
    }

}
