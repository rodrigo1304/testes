package exercicio9;

/**
 * Classe que representa um nó da arvore.
 *
 * @author Rodrigo de Lima Salvador
 */
public class Node {

    private int valor;
    private Node left;
    private Node right;

    public Node(int valor) {
        this.valor = valor;
    }

    public int sum() {
        return valor
                + (right == null ? 0 : right.sum())
                + (left == null ? 0 : left.sum());
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Node getLeft() {
        return left;
    }

    public void setLeft(Node left) {
        this.left = left;
    }

    public Node getRight() {
        return right;
    }

    public void setRight(Node right) {
        this.right = right;
    }
    
    public Node findNode(int valor) {
        if (valor == this.left.valor) {
            return this.left;
        } else if (valor == this.right.valor) {
            return this.right;
        } else {
            return null;
        }
    }

}
